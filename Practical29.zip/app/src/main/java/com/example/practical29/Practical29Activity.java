package com.example.practical29;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class Practical29Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical29);

        TextView target = findViewById(R.id.context_target);
        registerForContextMenu(target);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_bg_colors, menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.bg_red) {
            Toast.makeText(this, "Context: red", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.bg_green) {
            Toast.makeText(this, "Context: green", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.bg_blue) {
            Toast.makeText(this, "Context: blue", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onContextItemSelected(item);
    }
}
