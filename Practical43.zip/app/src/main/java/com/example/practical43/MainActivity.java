package com.example.practical43;

import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);

        findViewById(R.id.mode_normal).setOnClickListener(v -> {
            if (am != null) {
                am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
            }
            toastMode(am);
        });

        findViewById(R.id.mode_vibrate).setOnClickListener(v -> {
            if (am != null) {
                am.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
            }
            toastMode(am);
        });

        findViewById(R.id.mode_silent).setOnClickListener(v -> {
            if (am != null) {
                am.setRingerMode(AudioManager.RINGER_MODE_SILENT);
            }
            toastMode(am);
        });
    }

    private void toastMode(AudioManager am) {
        if (am == null) {
            Toast.makeText(this, "AudioManager null", Toast.LENGTH_SHORT).show();
            return;
        }

        int m = am.getRingerMode();
        String label = m == AudioManager.RINGER_MODE_NORMAL ? "Normal"
                : m == AudioManager.RINGER_MODE_VIBRATE ? "Vibrate" : "Silent/Other";

        Toast.makeText(this, "Mode: " + label, Toast.LENGTH_SHORT).show();
    }
}
