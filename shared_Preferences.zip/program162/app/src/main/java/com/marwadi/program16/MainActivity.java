package com.marwadi.program16;

import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etUsername, etPassword;
    Button btnLogin, btnRegister;

    // SharedPreferences key constants
    private static final String PREF_NAME = "UserPrefs";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";

    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        btnLogin   = findViewById(R.id.btn_login);
        btnRegister = findViewById(R.id.btn_register);

        // Initialize SharedPreferences
        sp = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        // ── REGISTER ──────────────────────────────────────────────
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this,
                            "Please enter username and password",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                // Save to SharedPreferences
                SharedPreferences.Editor editor = sp.edit();
                editor.putString(KEY_USERNAME, username);
                editor.putString(KEY_PASSWORD, password);
                editor.apply();

                Toast.makeText(MainActivity.this,
                        "Registered successfully!",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // ── LOGIN ─────────────────────────────────────────────────
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Check if any record exists in SharedPreferences
                if (sp.contains(KEY_USERNAME)) {

                    // Fetch stored credentials
                    String storedUser = sp.getString(KEY_USERNAME, "");
                    String storedPass = sp.getString(KEY_PASSWORD, "");

                    // Compare with what the user typed
                    String inputUser = etUsername.getText().toString().trim();
                    String inputPass = etPassword.getText().toString().trim();

                    if (inputUser.equals(storedUser) && inputPass.equals(storedPass)) {
                        Toast.makeText(MainActivity.this,
                                "Login successful! Welcome " + storedUser,
                                Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(MainActivity.this,
                                "Invalid username or password",
                                Toast.LENGTH_SHORT).show();
                    }

                } else {
                    // No record found in SharedPreferences
                    Toast.makeText(MainActivity.this,
                            "No Records Found",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}