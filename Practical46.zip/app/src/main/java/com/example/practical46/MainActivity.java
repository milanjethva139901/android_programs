package com.example.practical46;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS = "demo_prefs";
    private static final String KEY = "value";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText value = findViewById(R.id.value);
        Button save = findViewById(R.id.save);
        Button load = findViewById(R.id.load);

        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);

        save.setOnClickListener(v -> {
            sp.edit().putString(KEY, value.getText().toString()).apply();
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        });

        load.setOnClickListener(v ->
                value.setText(sp.getString(KEY, "")));
    }
}
